// Fichier Scene.java
// Auteur : LORENZELI Antony
// Contexte : TP5 ACD1
// Date : 19/03/2019

package graphescene;

import outils3d.Affichable;

/** Définition de la classe abstraite Scene. */
public abstract class Scene implements Affichable{
}
