Grille bien initialisé.
Affichage finit et fonctionnel.
Méthode estPossible implémentée et testée qui fonctionne.
