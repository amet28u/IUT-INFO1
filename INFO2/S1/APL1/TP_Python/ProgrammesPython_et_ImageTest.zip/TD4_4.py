long=int(input("Entrez la longeur : "))
larg=int(input("Entrez la largeur : "))
for i in range(0,long):
    for j in range(0,larg):
        print("*",end='')
    print("")
