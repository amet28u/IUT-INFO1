a=int(input("Entrez a :\n"))
b=int(input("Entrez b :\n"))
c=int(input("Entrez c :\n"))
somme=a+b+c
produit=a*b*c
moyenne=somme/3
print("Somme : ",somme," Produit : ",produit," Moyenne : ",moyenne)
