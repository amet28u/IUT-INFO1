h=int(input("Haureur du triangle : "))
for i in range(0,h):
    for j in range(h,i,-1):
            print(i,end='')
    print("")
