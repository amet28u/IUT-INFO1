a=int(input("Entrez a :\n"))
b=int(input("Entrez b :\n"))
a=b-a
b=b-a
a=a+b
print("a :",a,"b :",b)
