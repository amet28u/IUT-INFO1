a=int(input("Entrez a :\n"))
b=int(input("Entrez b :\n"))
c=a*b
if c<0:
    print("-")
else:
    print("+")
    
