for m in range(0,10):
    for n in range(0,10):
        if pow(m,2)+2*pow(n,2)<100:
            print("(",m,",",n,")\n")

        
