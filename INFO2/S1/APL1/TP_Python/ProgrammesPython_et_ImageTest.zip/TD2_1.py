c=input("Entrez c : ")
x=0
if c=="True":
    x=1
print(x)
