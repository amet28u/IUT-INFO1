#!/bin/bash

case $1 in
  'one') echo 'un';;
  'two') echo 'deux';;
  'three') echo 'trois';;
  'four') echo 'quatre';;
  'five') echo 'cinq';;
  'six') echo 'six';;
  'seven') echo 'sept';;
  'eight') echo 'huit';;
  'nine') echo 'neuf';;
  *);;
esac
