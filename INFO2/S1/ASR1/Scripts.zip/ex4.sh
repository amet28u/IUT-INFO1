#!/bin/bash

datedujour=date
date
echo "$datedujour"
